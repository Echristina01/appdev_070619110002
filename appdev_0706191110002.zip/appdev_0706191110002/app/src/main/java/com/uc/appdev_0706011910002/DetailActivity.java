package com.uc.appdev_0706011910002;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uc.appdev_706011910002.R;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}
