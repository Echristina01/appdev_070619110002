package com.uc.appdev_0706011910002;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.uc.appdev_0706011910002.Adapter.MyAdapter;
import com.uc.appdev_0706011910002.Model.SaveData;
import com.uc.appdev_0706011910002.Model.User;
import com.uc.appdev_706011910002.R;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements MyAdapter.OnContactListener {

    FloatingActionButton btn_add;
    RecyclerView mRecyclerView;
    ArrayList<User> mContacts = SaveData.saveList;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;
    TextView Kosong;
    User user;

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "tekan back 2x untuk Exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Kosong = findViewById(R.id.nodataTxt);

        if(mContacts.isEmpty()){
            Kosong.setVisibility(View.VISIBLE);
        } else {
            Kosong.setVisibility(View.INVISIBLE);
        }

        btn_add = findViewById(R.id.button_add_main);
//        nodata = findViewById(R.id.noData);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, AddUserActivity.class);
                intent.putExtra("position",-1);
                startActivity(intent);

            }
        });

        mRecyclerView = findViewById(R.id.recyclerView);

        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new MyAdapter(mContacts, this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);



    }


    @Override
    public void onContactClick(int position) {
        Log.d("clickwhy","onContactClick: clicked " + position);
        Intent intent = new Intent(this, UserActivity.class);
        intent.putExtra("contact_info",position);
        startActivity(intent);
    }
}
